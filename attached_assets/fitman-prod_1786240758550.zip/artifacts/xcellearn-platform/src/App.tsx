import { useState, useEffect } from 'react';
import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { LoadingScreen } from "@/components/LoadingScreen";
import { AppLayout } from "@/components/layout/AppLayout";
import Login from "@/pages/Login";

import AdminDashboard from "@/pages/admin/Dashboard";
import AdminUsers from "@/pages/admin/Users";
import AdminDepartments from "@/pages/admin/Departments";
import AdminFaculties from "@/pages/admin/Faculties";
import AdminCourses from "@/pages/admin/Courses";
import AdminAssignments from "@/pages/admin/Assignments";
import AdminActivity from "@/pages/admin/Activity";

import StudentDashboard from "@/pages/student/Dashboard";
import StudentProfile from "@/pages/student/Profile";
import StudentLibrary from "@/pages/student/Library";
import StudentAssignments from "@/pages/student/Assignments";

import LecturerDashboard from "@/pages/lecturer/Dashboard";
import LecturerProfile from "@/pages/lecturer/Profile";
import LecturerAssignments from "@/pages/lecturer/Assignments";
import LecturerSubmissions from "@/pages/lecturer/Submissions";

import Notifications from "@/pages/Notifications";
import { initializeDb } from '@/lib/db';
import { isDemoMode } from '@/lib/config';
import { hydrateAuth, useAuth } from '@/lib/auth';

const queryClient = new QueryClient();

function Router() {
  const [location, setLocation] = useLocation();
  
  useEffect(() => {
    if (location === '/') {
      setLocation('/login');
    }
  }, [location, setLocation]);

  return (
    <Switch>
      <Route path="/login" component={Login} />
      
      <Route path="/admin/*">
        <AppLayout>
          <Switch>
            <Route path="/admin/dashboard" component={AdminDashboard} />
            <Route path="/admin/users" component={AdminUsers} />
            <Route path="/admin/departments" component={AdminDepartments} />
            <Route path="/admin/faculties" component={AdminFaculties} />
            <Route path="/admin/courses" component={AdminCourses} />
            <Route path="/admin/assignments" component={AdminAssignments} />
            <Route path="/admin/activity" component={AdminActivity} />
            <Route component={NotFound} />
          </Switch>
        </AppLayout>
      </Route>

      <Route path="/student/*">
        <AppLayout>
          <Switch>
            <Route path="/student/dashboard" component={StudentDashboard} />
            <Route path="/student/profile" component={StudentProfile} />
            <Route path="/student/library" component={StudentLibrary} />
            <Route path="/student/assignments" component={StudentAssignments} />
            <Route path="/student/notifications" component={Notifications} />
            <Route component={NotFound} />
          </Switch>
        </AppLayout>
      </Route>

      <Route path="/lecturer/*">
        <AppLayout>
          <Switch>
            <Route path="/lecturer/dashboard" component={LecturerDashboard} />
            <Route path="/lecturer/profile" component={LecturerProfile} />
            <Route path="/lecturer/assignments" component={LecturerAssignments} />
            <Route path="/lecturer/submissions" component={LecturerSubmissions} />
            <Route path="/lecturer/notifications" component={Notifications} />
            <Route component={NotFound} />
          </Switch>
        </AppLayout>
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [dataReady, setDataReady] = useState(false);
  const [dataError, setDataError] = useState<string | null>(null);
  const { user } = useAuth();
  const [authReady, setAuthReady] = useState(isDemoMode);

  useEffect(() => {
    if (isDemoMode) return;

    hydrateAuth()
      .then(() => setAuthReady(true))
      .catch((error: unknown) => {
        setDataError(error instanceof Error ? error.message : 'Unable to restore the Supabase session.');
        setAuthReady(true);
      });
  }, []);

  useEffect(() => {
    if (!authReady) return;

    if (!isDemoMode && !user) {
      setDataReady(true);
      return;
    }

    setDataReady(false);
    initializeDb()
      .then(() => setDataReady(true))
      .catch((error: unknown) => {
        setDataError(error instanceof Error ? error.message : 'Unable to load application data.');
      });
  }, [authReady, user]);

  if (isLoading || !authReady || !dataReady) {
    return <LoadingScreen onComplete={() => setIsLoading(false)} />;
  }

  if (dataError) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-6">
        <div className="max-w-lg rounded-lg border bg-card p-6 text-center shadow-sm">
          <h1 className="text-xl font-semibold">Application setup required</h1>
          <p className="mt-2 text-sm text-muted-foreground">{dataError}</p>
        </div>
      </div>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
