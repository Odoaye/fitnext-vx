export type AppMode = 'demo' | 'supabase';

const configuredMode = import.meta.env.VITE_APP_MODE;

export const appMode: AppMode = configuredMode === 'supabase' ? 'supabase' : 'demo';
export const isDemoMode = appMode === 'demo';
export const isSupabaseMode = appMode === 'supabase';

export const supabaseUrl = String(import.meta.env.VITE_SUPABASE_URL ?? '').trim();
export const supabaseAnonKey = String(import.meta.env.VITE_SUPABASE_ANON_KEY ?? '').trim();
export const supabaseConfigured = Boolean(supabaseUrl && supabaseAnonKey);
export const seedSupabaseWhenEmpty = import.meta.env.VITE_SUPABASE_SEED_ON_EMPTY === 'true';

export function getSupabaseConfigurationError() {
  if (!isSupabaseMode) return null;
  if (!supabaseUrl || !supabaseAnonKey) {
    return 'Supabase mode is enabled, but VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are missing.';
  }
  return null;
}