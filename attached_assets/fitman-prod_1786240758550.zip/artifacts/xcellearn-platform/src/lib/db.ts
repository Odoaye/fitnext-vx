import { seedData } from './demoData';
import { isDemoMode, seedSupabaseWhenEmpty } from './config';
import { requireSupabase } from './supabase';

export type { User } from './demoData';
export type AppDatabase = typeof seedData;

const STORE_KEY = 'xcellearn_db';
const VERSION_KEY = 'xcellearn_db_version';
const DB_VERSION = 4;
const STATE_ROW_ID = 'default';

let currentDb: AppDatabase | null = null;
let persistPromise: Promise<void> = Promise.resolve();

function cloneSeedData(): AppDatabase {
  return JSON.parse(JSON.stringify(seedData)) as AppDatabase;
}

function setMemoryDb(data: AppDatabase) {
  currentDb = data;
  return data;
}

function loadDemoDb() {
  const version = localStorage.getItem(VERSION_KEY);
  if (version !== String(DB_VERSION)) {
    localStorage.setItem(STORE_KEY, JSON.stringify(seedData));
    localStorage.setItem(VERSION_KEY, String(DB_VERSION));
    return setMemoryDb(cloneSeedData());
  }

  const data = localStorage.getItem(STORE_KEY);
  if (!data) {
    localStorage.setItem(STORE_KEY, JSON.stringify(seedData));
    return setMemoryDb(cloneSeedData());
  }

  return setMemoryDb(JSON.parse(data) as AppDatabase);
}

export async function initializeDb(force = false) {
  if (currentDb && !force) return currentDb;
  if (force) currentDb = null;
  if (isDemoMode) return loadDemoDb();

  const { data, error } = await requireSupabase()
    .from('app_state')
    .select('payload')
    .eq('id', STATE_ROW_ID)
    .maybeSingle();

  if (error) {
    throw new Error(`Unable to load Supabase application data: ${error.message}`);
  }

  if (!data?.payload) {
    if (!seedSupabaseWhenEmpty) {
      throw new Error(
        'Supabase is connected, but the app_state row is empty. Run supabase/schema.sql and seed the app state before continuing.',
      );
    }

    const seeded = cloneSeedData();
    await persistSupabaseDb(seeded);
    return setMemoryDb(seeded);
  }

  return setMemoryDb(data.payload as AppDatabase);
}

export function getDb(): AppDatabase {
  if (!currentDb) {
    throw new Error('Application data has not finished loading.');
  }
  return currentDb;
}

export function saveDb(data: AppDatabase) {
  setMemoryDb(data);

  if (isDemoMode) {
    localStorage.setItem(STORE_KEY, JSON.stringify(data));
    localStorage.setItem(VERSION_KEY, String(DB_VERSION));
    return;
  }

  persistPromise = persistPromise
    .catch(() => undefined)
    .then(() => persistSupabaseDb(data));
}

async function persistSupabaseDb(data: AppDatabase) {
  const { error } = await requireSupabase().from('app_state').upsert({
    id: STATE_ROW_ID,
    payload: data,
    updated_at: new Date().toISOString(),
  });

  if (error) {
    throw new Error(`Unable to save Supabase application data: ${error.message}`);
  }
}

export function resetDb() {
  if (isDemoMode) {
    localStorage.setItem(STORE_KEY, JSON.stringify(seedData));
    localStorage.setItem(VERSION_KEY, String(DB_VERSION));
    setMemoryDb(cloneSeedData());
    return;
  }

  saveDb(cloneSeedData());
}

export function clearDbCache() {
  currentDb = null;
}