import { create, type StateCreator } from 'zustand';
import { persist } from 'zustand/middleware';
import { User } from './db';
import { isDemoMode } from './config';
import { requireSupabase } from './supabase';

interface AuthState {
  user: User | null;
  login: (user: User) => void;
  logout: () => void;
}

interface LoginProfile {
  id: string;
  email: string;
  name: string;
  username: string;
  role: User['role'];
  department_id?: string | null;
  faculty_id?: string | null;
  year?: number | null;
  courses?: string[] | null;
}

export async function authenticateUser(
  username: string,
  password: string,
  role: User['role'],
) {
  if (isDemoMode) {
    const { getDb } = await import('./db');
    const db = getDb();
    const user = db.users.find((candidate) => candidate.username === username && candidate.role === role);
    const validPassword = password === (user?.role === 'admin' ? 'admin123' : 'pass123');
    return user && validPassword ? user : null;
  }

  const client = requireSupabase();
  const { data: profileData, error: profileError } = await client
    .rpc('lookup_login_profile', {
      p_username: username,
      p_role: role,
    })
    .maybeSingle();
  const profile = profileData as LoginProfile | null;

  if (profileError) throw new Error(profileError.message);
  if (!profile?.email) return null;

  const { error: authError } = await client.auth.signInWithPassword({
    email: profile.email,
    password,
  });

  if (authError) return null;
  return {
    id: profile.id,
    name: profile.name,
    role: profile.role,
    username: profile.username,
    department_id: profile.department_id ?? undefined,
    faculty_id: profile.faculty_id ?? undefined,
    year: profile.year ?? undefined,
    courses: profile.courses ?? [],
  } satisfies User;
}

const createAuthStore = () => {
  const state: StateCreator<AuthState> = (set) => ({
    user: null,
    login: (user) => set({ user }),
    logout: () => set({ user: null }),
  });

  if (isDemoMode) {
    return create<AuthState>()(
      persist(state, {
        name: 'xcellearn_auth',
      }),
    );
  }

  return create<AuthState>()(state);
};

export const useAuth = createAuthStore();

export async function hydrateAuth() {
  if (isDemoMode) return useAuth.getState().user;

  const client = requireSupabase();
  const { data: sessionData } = await client.auth.getSession();
  const session = sessionData.session;

  if (!session?.user) {
    useAuth.setState({ user: null });
    return null;
  }

  const { data: profile, error } = await client
    .from('profiles')
    .select('id, name, username, email, role, department_id, faculty_id, year, courses')
    .eq('id', session.user.id)
    .maybeSingle();

  if (error) throw new Error(error.message);
  if (!profile) {
    useAuth.setState({ user: null });
    return null;
  }

  const user = {
    id: profile.id,
    name: profile.name,
    role: profile.role,
    username: profile.username,
    department_id: profile.department_id ?? undefined,
    faculty_id: profile.faculty_id ?? undefined,
    year: profile.year ?? undefined,
    courses: profile.courses ?? [],
  } satisfies User;

  useAuth.setState({ user });
  return user;
}
