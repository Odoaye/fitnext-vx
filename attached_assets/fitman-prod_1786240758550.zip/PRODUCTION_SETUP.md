# XcelLearn production handoff

This package is prepared for local preview now and Supabase + Vercel later.

## Local preview

```bash
pnpm install
pnpm --filter @workspace/xcellearn-platform run dev
```

The default local mode is `demo`, so the included sample accounts still work:

- Admin: `admin` / `admin123`
- Student: `student1` / `pass123`
- Lecturer: `lect1` / `pass123`

## Supabase mode

1. Create a Supabase project.
2. Run `supabase/schema.sql` in the Supabase SQL Editor.
3. Create users in Supabase Authentication.
4. Add matching rows to `public.profiles`.
5. Set these Vercel environment variables:

```text
VITE_APP_MODE=supabase
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
VITE_SUPABASE_SEED_ON_EMPTY=false
```

The browser client only uses the public anonymous key. Never put the Supabase service-role key in Vercel frontend variables.

The included SQL creates a narrowly scoped `lookup_login_profile` function because
the login form accepts usernames while Supabase Auth signs in with email. The
function returns only the matching profile needed to start authentication; the
normal profile policy still protects profile reads after sign-in.

## Vercel settings

For a repository containing this workspace:

- Framework preset: Vite
- Build command: `pnpm --filter @workspace/xcellearn-platform run build`
- Output directory: `artifacts/xcellearn-platform/dist/public`
- Install command: `pnpm install --frozen-lockfile`

The root `vercel.json` includes these defaults and rewrites SPA routes to `index.html`.

## Data handoff note

The current UI uses a compatibility `app_state` JSON document so the existing demo screens can run without a large frontend rewrite. It is suitable for preview and initial Supabase wiring. Before handling large institutional traffic, migrate the payload into normalized Supabase tables with row-level policies for each role and entity.