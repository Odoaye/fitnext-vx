-- XcelLearn Supabase handoff schema.
-- Run this in Supabase SQL Editor before setting VITE_APP_MODE=supabase.

create extension if not exists pgcrypto;

create type public.app_role as enum ('admin', 'student', 'lecturer');

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique not null,
  name text not null,
  username text unique not null,
  role public.app_role not null default 'student',
  department_id text,
  faculty_id text,
  year integer,
  courses text[] not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.app_state (
  id text primary key check (id = 'default'),
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

-- The login form uses a username, while Supabase Auth signs in with email.
-- This function exposes only the matching profile needed to begin sign-in.
create or replace function public.lookup_login_profile(
  p_username text,
  p_role public.app_role
)
returns table (
  id uuid,
  email text,
  name text,
  username text,
  role public.app_role,
  department_id text,
  faculty_id text,
  year integer,
  courses text[]
)
language sql
security definer
set search_path = public
stable
as $$
  select
    p.id,
    p.email,
    p.name,
    p.username,
    p.role,
    p.department_id,
    p.faculty_id,
    p.year,
    p.courses
  from public.profiles p
  where p.username = p_username
    and p.role = p_role
  limit 1;
$$;

revoke all on function public.lookup_login_profile(text, public.app_role) from public;
grant execute on function public.lookup_login_profile(text, public.app_role) to anon, authenticated;

alter table public.profiles enable row level security;
alter table public.app_state enable row level security;

drop policy if exists "Users can read their own profile" on public.profiles;
create policy "Users can read their own profile"
  on public.profiles for select
  to authenticated
  using (auth.uid() = id);

drop policy if exists "Authenticated users can read app state" on public.app_state;
create policy "Authenticated users can read app state"
  on public.app_state for select
  to authenticated
  using (true);

drop policy if exists "Authenticated users can update app state" on public.app_state;
create policy "Authenticated users can update app state"
  on public.app_state for update
  to authenticated
  using (true)
  with check (true);

drop policy if exists "Authenticated users can insert app state" on public.app_state;
create policy "Authenticated users can insert app state"
  on public.app_state for insert
  to authenticated
  with check (id = 'default');

insert into public.app_state (id, payload)
values ('default', '{}'::jsonb)
on conflict (id) do nothing;

-- Create users in Authentication first, then insert matching profile rows.
-- Do not store passwords in this database table.